//
//  main.swift
//  calculoUsuario2505392015
//
//  Created by Development on 4/29/22.
//  Copyright © 2022 Development. All rights reserved.
//

import Foundation

print("Hello, World!")

func leerteclado() -> String {
    var captura:String=""
    captura=NSString(data: FileHandle.standardInput.availableData,
                     encoding: String.Encoding.utf8.rawValue)! as String
    captura=captura.replacingOccurrences(of: "\n", with: "",
        options: NSString.CompareOptions.literal, range: nil)
    return captura
}

func operacionbasica(pval1:Double, pval2:Double, popc:Int) -> Double {
    var resul:Double=0.00
    if popc==1{
        resul=pval1+pval2
    }
    if popc==2{
        resul=pval1-pval2
    }
    if popc==3{
        resul=pval1*pval2
    }
    if popc==4{
        resul=pval1/pval2
    }
    return resul
}

var lectura:String=""
var valor1:Double=0.00
var valor2:Double=0.00
var opc : Int=0
print("Ingresar valor 1 :")
lectura=leerteclado()
valor1=Double(lectura)!
print("Ingresar valor 2 :")
lectura=leerteclado()
valor2=Double(lectura)!
print("Operacion de realizar :")
lectura=leerteclado()
opc=Int(lectura)!

print(operacionbasica(pval1: valor1, pval2: valor2, popc: opc))
