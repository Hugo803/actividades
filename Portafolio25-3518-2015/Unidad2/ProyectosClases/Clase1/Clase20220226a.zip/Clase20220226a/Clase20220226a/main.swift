//
//  main.swift
//  Clase20220226a
//
//  Created by Development on 4/11/22.
//  Copyright © 2022 Development. All rights reserved.
//

import Foundation

print("Hello, World!")

/*for i in 0..<10 {
  print("The index is: \(i)")
}
*/

var x:Int=5
var y:Int=5
while x >= y {
    print("Si")
    y=0
}
