//
//  main.swift
//  Clase20220312a
//
//  Created by Development on 4/29/22.
//  Copyright © 2022 Development. All rights reserved.
//

import Foundation

print("Hello, World!")
//Arrays -- arreglos

var a2:[String] = [String]()
var a3=["a","b","c"]

a2.append("Prueba1")
a2.append("Prueba3")

a3.remove(at: 2)
a3.insert("c", at: 1)
print(a3)
a3[1]="b"
a3[2]="c"
a2.append("Prueba 4")
a2.append("Prueba 5")
a2.insert("Prueba 2", at: 1)

print(a3)
print(a2[1])
print(a3[2])
print(a3.count)
print(a2)
