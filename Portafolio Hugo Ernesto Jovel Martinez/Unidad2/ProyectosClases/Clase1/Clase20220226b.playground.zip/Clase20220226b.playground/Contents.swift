//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

//Operador de rango
0..<10
//Estructura de repeticion
for i in 0..<10 {
    print(i)
}

//tipo Bol true o false
//var h:Bool = true
//Estructura de repeticion while
//while h {
  //  print(h)
    //h=false
//}

// operadores de comparacion
//var x:Int=5
//var y:Int=6

//x == y //igual a
//x != y //not igual a
//x > y //mayor que
//x >= y //mayor que o igual a
//x < y //menor que
//x <= y //menor igual oigual a
//x === y //Dos objetos iguales
//x !== y //Dos objetos no son iguales
