//
//  Autor.swift
//  BookStore
//
//  Created by alexis on 23/3/21.
//  Copyright © 2021 alexis. All rights reserved.
//

import UIKit

class Autor: NSObject {

}
