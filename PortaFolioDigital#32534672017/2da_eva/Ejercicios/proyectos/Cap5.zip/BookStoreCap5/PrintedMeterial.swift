//
//  PrintedMeterial.swift
//  BookStore
//
//  Created by alexis on 23/3/21.
//  Copyright © 2021 alexis. All rights reserved.
//

import UIKit

// creando una super clase 
class PrintedMeterial: NSObject {

    var Title:String=""
    var PublishDate:String=""
    var PageCount:String=""
    var Price:String=""
    var Publisher:String=""
    
    func accion() -> String {
        return ""
    }
    
}
