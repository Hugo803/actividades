//
//  Author.swift
//  BookStore
//
//Created by angel deras on 23/3/21.
//  Copyright © 2021 angel deras All rights reserved.
//

import UIKit

class Author: NSObject {
    var fullName = ""
    var shortName = ""
    var place_of_birth=""
    var year_old=""
    var address = ""
    var city = ""
    var history=""
    
    
    func Perfil() -> String{
        
        fullName = "Angel Deras"
        shortName=" Angel"
        place_of_birth="San Salvador"
        year_old = "26 años"
        address=" San Salvador #23"
        city=" San Salvador "
        history = "26 años"
        
        return "Nombre del Autor: \(self.fullName), de edad  \(self.year_old)"
    }
    
}
