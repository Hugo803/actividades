//
//  ViewController.swift
//  Capitulo6
//
//Created by angel deras on 23/3/21.
//  Copyright © 2021 angel deras All rights reserved.//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var name1Label: UILabel!
    @IBAction func showName (sender: AnyObject)
    {
      nameLabel.text = "My Name is Angel Deras! "
        
    }
    
    @IBAction func showCapitulo (sender: AnyObject)
    {
        
            name1Label.text = "capitulo 6 de libro de texto"
        
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

