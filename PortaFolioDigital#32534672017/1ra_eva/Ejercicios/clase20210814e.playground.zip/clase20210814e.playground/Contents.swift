//: Playground - noun: a place where people can play

import UIKit

//Estructura de repeticion (Listin 4-8)
for i in 1..<100{
    print("El numero es: \(i)")
}
