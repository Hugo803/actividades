//: Playground - noun: a place where people can play

import UIKit

//var str = "Hello, playground"

var numero:  Int = 5
// tabla 4-7 operadores de comparacion

var valor1 = 4
var valor2 = 5

if (valor1 <= valor2)
{
    print("Si")
}
else
{
    print("No")
}
