//: Playground - noun: a place where people can play

import UIKit

//Elaborar un programa que calcule el interes simple de un monto  "X"
//
//a) Definir formula
//b) Definir variable
//c) Escribir el codigo para el calculo
/*
I= cit
I= Interes simple
c= Monto o capital
i=tasa de interes
*/
var I:Double=0.0
var c:Double=0.0
var i:Double=0.0
var t:Double=0.0
c=5000.00
i=12.00
t=3
I=c*i*t	
print("El Interes es \(I)")
