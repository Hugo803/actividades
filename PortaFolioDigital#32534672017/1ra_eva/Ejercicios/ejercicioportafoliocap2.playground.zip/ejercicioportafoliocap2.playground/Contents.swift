//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
//EJERCICIO CAPITULO 2

//Ext	end your playground by adding = line of code tha print any text of your chossing\

str = "EJERCICIO CAPITULO 2"
print(str)
