	//: Playground - noun: a place where people can play

import UIKit

//var str = "Hello, playground"
//Elaborar un programa del calculo de las 4 operaciones basicas
//de dos numero cualquiera, usuario decide que operacion realizar
//opcion de operacion puede tener valores de S = Suma, R = Resta,
//M = Multiplicacion y D = Division
var opcion = "D"
var valor1 = 1.5
var valor2 = 5.0
var result = 0.0
if opcion == "S" {
    result = valor1 + valor2
}
if opcion == "R" {
    result = valor1 - valor2
}
if opcion == "M"{
result == valor1 * valor2
}
if opcion == "D"{
if (valor2 != 0){
    result = valor1/valor2
}
else {
    print("No se puede dividir entre cero")
    }
}
print ("El resultado de la operacion es \(result)")
