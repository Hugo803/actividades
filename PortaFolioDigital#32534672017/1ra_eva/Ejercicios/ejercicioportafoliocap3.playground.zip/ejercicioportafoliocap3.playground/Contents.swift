//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//EJERCICIO CAPITULO 3
//MULTIPLIQUE DOS ENTEROS Y MUESTRE EL RESUTLADO

let num1:  Int = 1
let num2:  Int = 5
let result:  Int

result = num1*num2
print(result)

//ELEVE EL CUADRADO UN FLOAT

let n1: Float=5.5
let cuadrado: Float

cuadrado = pow(n1, 2)
print(cuadrado)

//RESTAR DOS FLOAT Y ALMACENARLOS COMO ENTERO

let nu1: Float = 10.5
let nu2: Float=6.9
let res=Int((nu1-nu2))
print(res)
