//: Playground - noun: a place where people can play

/*
 Hecho por: Cristian Vladimir Garcia Ayala
 Fecha: Jul 31, 2021
 */

import UIKit

//var str = "Hello, playground"
//La suma de dos numeros enteros
var valor1:Int = 3
var valor2:Int = 4
var resula:Int = 0 //A variable se asigna el resultado de operacion.

resula=valor1 + valor2

print("La suma de \(valor1) mas \(valor2) es : \(resula)")

