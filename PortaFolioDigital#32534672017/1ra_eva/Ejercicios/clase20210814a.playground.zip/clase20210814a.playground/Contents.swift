//: Playground - noun: a place where people can play

/*
 Hecho por: Cristian Vladimir Garcia Ayala
 Fecha: Ago 14, 2021
 */
import UIKit


var str = "Hello, playground"
let a=1
var firstNumber = 2
var secondNumber = 3

var totalSum = firstNumber + secondNumber

firstNumber = firstNumber + 1
secondNumber = secondNumber + 1
totalSum = firstNumber + secondNumber

print("totalSum = \(totalSum)")
	
