//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
//Elabora una tabla de multiplicar para el numero 5

var resul = 0
var number = 5
for i in 1..<10 {
    resul = i * number
    print("\(i) * \(number) = \(resul)")
}



