//
//  Informacion+CoreDataClass.swift
//  Parcial42562862014
//
//  Created by aureliano on 19/5/21.
//  Copyright © 2021 aureliano. All rights reserved.
//
//Aureliano Martinez
//25-6286-2014

import Foundation
import CoreData

@objc(Informacion)
public class Informacion: NSManagedObject {
    

}
