//
//  ViewController.swift
//  clase4_05052021b
//
//  Created by alexis on 5/5/21.
//  Copyright © 2021 alexis. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtname: UITextField!

    @IBOutlet weak var txtlastname: UITextField!
    
    
    @IBOutlet weak var txtage: UITextField!
    
    @IBOutlet weak var txthourlyrate: UITextField!
    
    @IBOutlet weak var txtemployeenumber: UITextField!
    
    
    @IBOutlet weak var lblresultado: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

   
    
    @IBAction func btnPerson(_ sender: UIButton) {
        let p1=Person()
        p1.name=txtname.text!
        p1.lastName=txtlastname.text!
        p1.age=Int(txtage.text!)!
        lblresultado.text=p1.profile()
    }
    
   
    @IBAction func btnEmployee(_ sender: Any) {
        let e1 = Employee()
        e1.name=txtname.text!
        e1.lastName=txtlastname.text!
        
        e1.employeeNumber=Int(txtemployeenumber.text!)!
        e1.hourlyRate=Double(txthourlyrate.text!)!
        
        lblresultado.text=e1.profile()
    }


}

