//
//  Person.swift
//  clase4_05052021b
//
//  Created by alexis on 5/5/21.
//  Copyright © 2021 alexis. All rights reserved.
//

import Foundation

class Person {
    var name:String
    var age:Int
    
    func profile() -> String {
        return "Yo \(self.name) de edad \(self.age)."
    }
    init() {
        self.name = "Name"
        self.age = 0
    }
    
    init(name:String, age:Int){
        self.name=name
        self.age=age
    }
    
    deinit{
        //removver
    }
    
    private var _lastName:String=""
    var lastName:String{
        get{
            return _lastName
        }
        set{
            _lastName = newValue
        }
    }
}
