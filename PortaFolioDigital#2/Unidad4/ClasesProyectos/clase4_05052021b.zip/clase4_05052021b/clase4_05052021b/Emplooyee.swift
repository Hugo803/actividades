//
//  Emplooyee.swift
//  clase4_05052021b
//
//  Created by alexis on 5/5/21.
//  Copyright © 2021 alexis. All rights reserved.
//

import Foundation

class Employee: Person{
    var employeeNumber=123456789
    var hourlyRate=12.00
    
     override func profile() -> String {
        return "Yo \(self.name) \(self.lastName) hourly rate \(self.hourlyRate)"
    }
    
}
