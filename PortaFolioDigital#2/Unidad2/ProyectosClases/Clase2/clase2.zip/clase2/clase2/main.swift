//
//  main.swift
//  clase2
//
//  Created on 1/3/21.

import Foundation


var opc:String=""
//opc="C"

if opc=="C" {
//Funciones.
func getPhrase()-> String {
    
    return "Hola Swift"
}

var mensaje = getPhrase()
print(mensaje)

func operaciones(val1:Int,val2:Int) -> Int
{
    var resl=0
    resl = val1 + val2
    return resl
}
print(operaciones(val1: 5,val2: 7))
}

/*
 Modificar el ejercicio de la pagina 49 de libro hacer una funcion para solicitar y capturar los datos.
 */

opc="R"
if opc=="R"
{
    var randomNumber = 1
    var userGuess: Int? = 1
    var continueGuessing = true
    var keepPlaying = true
    var input = ""
    func leer() -> String {
 var resultado=""
        resultado=NSString(data: FileHandle.standardInput.availableData, encoding:String.Encoding.utf8.rawValue)! as String
        resultado = resultado.replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range: nil)
        return resultado
        }
    
    while keepPlaying {
        randomNumber = Int(arc4random_uniform(101))
        print("The random number to guess is: \(randomNumber)")
        while continueGuessing {
            print("Pick a number between 0 and 100.")
            input = leer()
            userGuess = Int(input)
            if userGuess == randomNumber {
                continueGuessing = false
                print("Correct number!")
            } else if userGuess! > randomNumber {
            print("Your guess is too high elevado")
            }
            else{
            print("Your guess is too low bajo")
        }
    }
        
    print ("Play Again? Y or N")
    input = leer()
    if input == "N" || input == "n" {
        keepPlaying = false
    }
    continueGuessing = true
    }
}

/* Realizar un programa que realice las 4 operaciones basicas, en atencion a peticion del usuario, y debe guardar cada operacion, para que el usuario poueda ver al final todas las operaciones que ha realizado.
 */

