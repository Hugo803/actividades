//
//  Book.swift
//  BookStore
//
//  
//

import Foundation

class Book {
    var title:String=""
    var author:String=""
    var precio:String=""
    var genero:String=""
    var description:String=""
    
}
