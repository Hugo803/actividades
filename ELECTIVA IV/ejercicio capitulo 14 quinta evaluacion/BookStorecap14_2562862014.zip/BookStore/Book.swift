//
//  Book.swift
//  BookStore
//
//  Created by Development on 23/3/21.
//  Copyright © 2021 Development. All rights reserved.
//

import Foundation

class Book {
    var title:String=""
    var author:String=""
    var precio:String=""
    var genero:String=""
    var description:String=""
    var pages: Int = 0
    var readThisBook: Bool = false
}
