//
//  BookStore.swift
//  BookStore
//
//  Created by Development on 23/3/21.
//  Copyright © 2021 Development. All rights reserved.
//

import Foundation

class BookStore {
    var theBookStore: [Book] = []
    
    init() {
        
        var newBook=Book()
        newBook.title="Swift For Absolute Beginners"
        newBook.author="Bennett and Lees"
        newBook.precio="250.75"
        newBook.genero="Science"
        newBook.description="iOS Programming made easy"
        
        theBookStore.append(newBook)
        
        newBook=Book()
        newBook.title="A Farewell To Arms"
        newBook.author="Ernest Hemingway"
        newBook.precio="350.25"
        newBook.genero="Science"
        newBook.description="The story of an affair between an english nurse and an American Soldier on the Italian front during World War I"
        theBookStore.append(newBook)
        
        newBook=Book()
        newBook.title="The Nassa Life"
        newBook.author="Jwhens Trwind"
        newBook.precio="650.25"
        newBook.genero="Sociality"
        newBook.description="The story of OVNI"
        theBookStore.append(newBook)
        
        newBook=Book()
        newBook.title="The Algebra "
        newBook.author="Constatnti "
        newBook.precio="210.25"
        newBook.genero="Fictions"
        newBook.description="The story of Algebra"
        theBookStore.append(newBook)
    }
    
}
