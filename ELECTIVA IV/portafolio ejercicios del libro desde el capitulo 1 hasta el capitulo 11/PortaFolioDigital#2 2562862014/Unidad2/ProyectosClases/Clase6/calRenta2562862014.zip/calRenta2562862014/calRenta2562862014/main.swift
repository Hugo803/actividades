//
//  main.swift
//  calRenta2562862014
//
//  Created by aureliano on 10/3/21.
//  Copyright © 2021 aureliano. All rights reserved.
//

//Aureliano Martinez
//25-6286-2014

import Foundation

var duis:[String]=[String]()
var nombres:[String]=[String]()
var salarios:[Double]=[Double]()
var fps:[String]=[String]()
var rentas:[Double]=[Double]()

func calcularenta()->String
{    var prefer = true //tk
    var continuar = true //bda
    var opcion = 0
    //  var periodo: Int=0
    //   var montorenta: Double = 0
    // var montosalarioliquido: Double = 0
    
    
    var salario:Double=0.00
    var nombre:String=""
    var dui:String=""
    var renta: Double=0;
    
    
    print("  CALCULAR RENTA ")
    
    while prefer {
        
        print("  INGRESE NUMERO DE DUI : ")
        dui = String(getInputText())!
        
        print("  INGRESE NOMBRE : ")
        nombre = String(getInputText())!
        
        print("  INGRESE SALARIO : ")
        salario = Double(getInputText())!
        
        menuOpciones()
        opcion = Int(getInputText())!
        /*  if opcion == 4
         {
         if historialCantidad.count > 0 {
         mostrarHistorial(arrayValues: historialCantidad, arrayOperacion: historialActividad)
         }else{
         print("No hay operaciones realizadas")
         }
         }
         */
        
        // else
        if opcion > 0 && opcion < 4{
            
            
            /*
             print("  INGRESE NUMERO DE DUI : ")
             dui = String(getInputText())!
             
             print("  INGRESE NOMBRE : ")
             nombre = String(getInputText())!
             
             print("  INGRESE SALARIO : ")
             salario = Double(getInputText())!
             
             
             print("Digite el primer numero")
             num1 = Double(getInputText())!
             print("Digite el segundo numero")
             num2 = Double(getInputText())!
             
             */
            
            continuar = true
            
            /*   if opcion == 1 {
             resultado=sumar(num1: num1, num2: num2)
             tipo="SUMA"
             } else if opcion == 2 {
             resultado = restar(num1: num1, num2: num2)
             tipo="RESTA"
             } else if opcion == 3 {
             resultado=multiplicar(num1: num1, num2: num2)
             tipo="MULTIPLICACION"
             } else if opcion == 4 {
             if num2 != 0 {
             resultado = dividir(num1: num1, num2: num2)
             tipo="DIVISION"
             }else{
             continuar = false
             print("no se puede dividr entre cero")
             }
             }
             else{
             resultado = 0.00
             print("opcion invalida")
             continuar = false
             }
             
             */
            var tiempo:String=""
            
            if (opcion == 3)
            {
                tiempo="S"
                if (salario >= 0.01 && salario <= 118.00){renta = 0.00}
                if (salario >= 118.01 && salario <= 223.81){renta = (((salario - 118.00)*0.1)+4.42)}
                if (salario >= 223.82 && salario <= 509.52){renta = (((salario - 223.81)*0.20)+15.00)}
                if (salario >= 509.53){renta = (((salario - 509.52)*0.30)+72.14)}
            }
            if (opcion == 2)
            {
                tiempo="Q"
                if (salario >= 0.01 && salario <= 236.00){renta = 0.00}
                if (salario >= 236.01 && salario <= 447.62){renta = (((salario - 236.00)*0.1)+8.83)}
                if (salario >= 447.63 && salario <= 1019.05){renta = (((salario - 447.62)*0.20)+30.00)}
                if (salario >= 1019.06){renta = (((salario - 1019.05)*0.30)+144.28)}
            }
            
            if (opcion == 1)
            {
                tiempo="M"
                if (salario >= 0.01 && salario <= 472.00){renta = 0.00}
                if (salario >= 472.01 && salario <= 895.24){renta = (((salario - 472.00)*0.1)+17.67)}
                if (salario >= 895.25 && salario <= 2038.10){renta = (((salario - 895.24)*0.20)+60.00)}
                if (salario >= 2038.11){renta = (((salario - 2038.10)*0.30)+288.57)}
            }
            
            
            
            if continuar {
                // mostrar resultado
                
                
                var linea1:String=""
                linea1=String(repeating: "\u{2550}", count: 63 )
                print("\u{2554}\(linea1)\u{2557} ")
                print("\u{2551}    DUI               NOMBRE           SALARIO   FP   RENTA    \u{2551}")
                print("\u{255A}\(linea1)\u{255D} ")
                print("  \(dui)   \(nombre)    \(salario)   \(tiempo)   \(renta)")
                
                duis.append(dui)
                nombres.append(nombre)
                salarios.append(salario)
                fps.append(tiempo)
                rentas.append(renta)
                
                print ("   ")
                print ("  Desea realizar otro Calculo ingrese(1, 2, 3)")
                print ("  1  Si ")
                print ("  2  Ver Historial y Salir")
                print ("  3  Salir ")
                
                opcion = Int(getInputText())!
                if opcion > 0 && opcion < 4 {
                    if opcion == 1
                    { prefer = true }
                    
                    if opcion == 2
                    {
                        mostrarHistorial(arrayValues: rentas, arrayOperacion: duis, arrayValues1: nombres, arrayValues2: salarios, arrayValues3: fps)
                        prefer = false
                    }
                    
                    if opcion == 3
                    { prefer = false }
                }
                // prefer = false
            }
            /*if tipo == "N" || tipo == "n" {
             if( ){}
             else{
             prefer = false                    }
             // prefer = false
             }
             }*/
        }
        else {
            print("Opcion invalida")
        }
        
    }
    return "";
}

/*var calcula: Double=0
 
 calcula=calcularenta(salario: salario, periodo: periodo)
 
 montosalarioliquido = salario - calcula
 */


func menuOpciones() {
    
    print("  INGRESE FORMEA DE PAGO ( 1 , 2 , 3 ) ")
    print("  (  1  Mensual   )    ")
    print("  (  2  Quincenal )  ")
    print("  (  3  Semanal   ) ")
}

func mostrarHistorial(arrayValues: [Double], arrayOperacion: [String],arrayValues1: [String],arrayValues2: [Double],arrayValues3: [String]){
    var i = 0
    print("--- Historial de Renta Calculada --- ")
    var linea1:String=""
    linea1=String(repeating: "\u{2550}", count: 63 )
    print("\u{2554}\(linea1)\u{2557} ")
    print("\u{2551}    DUI               NOMBRE           SALARIO   FP   RENTA    \u{2551}")
    print("\u{255A}\(linea1)\u{255D} ")
    
    
    for itemHistorial in arrayValues{
        
        
        
        print(" \(arrayOperacion[i]).  \(arrayValues1[i]).   \(arrayValues2[i])  \(arrayValues3[i])  \(itemHistorial) ")
        // print("\(i+1)-) Nombre \(arrayOperacion[i]) Salario \(itemHistorial)")
        i=i+1
    }
    
}

func getInputText() -> String {
    var input = ""
    input=NSString(data: FileHandle.standardInput.availableData, encoding:String.Encoding.utf8.rawValue)! as String
    input = input.replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range: nil)
    return input
}


print(calcularenta())

