//
//  Customer.swift
//  BookStore2562862014

//  Copyright © 2021 aureliano. All rights reserved.
//

import UIKit

class Customer: NSObject {
    // propiedades de la clase.
    var firstName = ""
    var lastName = ""
    var addressline1 = ""
    var addressline2 = ""
    var city = ""
    var state = ""
    var zip = ""
    var phoneNumber = ""
    var mailAddress = ""
    var favoriteGenre = ""
    
    // funcion.
    func listPurchaseHistory() -> [String]
    {
        return ["Purchase1","Purchase2"]
    }
}
