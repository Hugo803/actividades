//: Playground - noun: a place where people can play
// Clase miercoles 24 de febrero.
import UIKit

var str = "Hello, playground"

//Funciones.
func getPhrase()-> String {
    
    return "Hola Swift"
}

var mensaje = getPhrase()
print(mensaje)

func operaciones(val1:Int,val2:Int) -> Int
{
    var resl=0
resl = val1 + val2
    return resl
}
print(operaciones(val1: 5,val2: 7))

/*
 Modificar el ejercicio de la pagina 49 de libro hacer una funcion
 para solicitar y capturar los datos.
 */
