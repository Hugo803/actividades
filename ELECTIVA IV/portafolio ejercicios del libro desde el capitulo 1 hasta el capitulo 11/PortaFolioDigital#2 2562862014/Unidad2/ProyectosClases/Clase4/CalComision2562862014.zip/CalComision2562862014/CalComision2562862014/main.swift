//
//  main.swift
//  CalComision2562862014
//
//
//  Created by Development on 3/1/21.
//  Copyright © 2021 Development. All rights reserved.
//

//Aureliano Martinez
//25-6286-2014

import Foundation

var salario:Double=0.00
var unidades:Int=0
var comision:Double=0.00
var valor1:Double=0.00
var valor2:Double=0.00
var salarioneto:Double=0.00
var leer:String=""



func capturar() -> String {
    
    var dato:String=""
    dato=NSString(data: FileHandle.standardInput.availableData, encoding: String.Encoding.utf8.rawValue)! as String
    dato=dato.replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range: nil)
    return dato
    
    
}
//www.LookupTables.com
var line1:String=""
line1=String(repeating: "\u{2550}", count:25)
print ("\u{2554}\(line1)\u{2557}")
print ("\u{2551} Calculo de Salario Neto \u{2551}")
print ("\u{255A}\(line1)\u{255D}")

print ("Ingresar Salario Base")
leer=NSString(data: FileHandle.standardInput.availableData, encoding: String.Encoding.utf8.rawValue)! as String
leer=leer.replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range: nil)
salario=Double(leer)!
print("Ingresar Numero de Unidades :")
leer=NSString(data: FileHandle.standardInput.availableData, encoding: String.Encoding.utf8.rawValue)! as String
leer=leer.replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range: nil)
unidades=Int(leer)!
switch unidades{
case 0...100:
    valor1=0.00
case 101...200:
    valor1=0.02
case 201...300:
    valor1=0.03
case 301...400:
    valor1=0.04
    if unidades>=350 && unidades<=400 {
        valor2=0.01
    }
case 401...500:
    valor1=0.05
case 501...600:
    valor1=0.06
case 601...700:
    valor1=0.07
    if unidades>=650 && unidades<=700 {
        valor2=0.013
    }
case 701...800:
    valor1=0.08
case 801...900:
    valor1=0.09
case 901...1000:
    valor1=0.10
    
    if unidades>=950 && unidades<=1000 {
        valor2=0.015
    }
default:
    valor1=0.11
    if unidades>=1500{
        valor2=0.02
    }
}

// del anterior programa realizar lo siguiente cambios o mejoras
//Crear una clase de nombre Calcomi
//Incorporar dos metodos para calcular la comision y el premio
//

class Calcomi{
    
    func Comision() -> Double{
        var comision1:Double=0.00
        comision1=(Double(unidades)*valor1)
        return comision1
    }
    
    func Premio() -> Double{
        var premio1:Double=0.00
         premio1=(Double(unidades) * valor2)
        return premio1
    }
    
}

print(" La comision es: \(Calcomi().Comision())")
print(" El premio es: \(Calcomi().Premio())")

comision=(Calcomi().Comision() + Calcomi().Premio())

// comision=(Double(unidades)*valor1)+(Double(unidades) * valor2)

salarioneto=salario + comision
print(" Total Comision : \(comision)")
print(" Salario neto: \(salarioneto)")


