//
//  Calcomi.swift
//  CalComision2562862014
//
//  Created by alexis on 14/3/21.
//  Copyright © 2021 aureliano. All rights reserved.
//

import Cocoa

class C1alcomi: NSObject {
    

}
