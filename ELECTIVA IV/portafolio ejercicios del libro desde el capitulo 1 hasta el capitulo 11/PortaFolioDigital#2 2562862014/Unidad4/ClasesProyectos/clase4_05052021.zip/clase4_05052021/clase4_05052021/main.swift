//
//  main.swift
//  clase4_05052021
//
//  Created by alexis on 5/5/21.
//  Copyright © 2021 alexis. All rights reserved.
//

import Foundation

class Person {
    var name:String
    var age:Int
    
    func profile() -> String {
        return "Yo \(self.name) de edad \(self.age)."
    }
    init() {
        self.name = "Name"
        self.age = 0
    }
    
    init(name:String, age:Int){
        self.name=name
        self.age=age
    }
    
    deinit{
        //removver
    }
    
    private var _lastName:String=""
    var lastName:String{
    get{
    return _lastName
    }
    set{
            _lastName = newValue
    }
}
}
//Herencia 
class Employee: Person{
    var employeeNumber=123456789
    var hourlyRate=12.00
    
    override func profile() -> String {
        return "Yo \(self.name) \(self.lastName) hourly rate \(self.hourlyRate)"
    }
    
}

var p1=Person()
p1.name="Matt"
p1.lastName="Campbell"
p1.age=40
print(p1.profile())

var e1 = Employee()
e1.name="Jim"
e1.lastName="Smith"
e1.age=18
e1.employeeNumber=1
e1.hourlyRate=15.50

print(e1.profile())


/*
var p = Person(name: "Matt", age: 40)
var e = Employee()

print(p.name)
print(p.age)
print(p.profile())

e.employeeNumber=752
e.hourlyRate=8
print(e.name)
 */


