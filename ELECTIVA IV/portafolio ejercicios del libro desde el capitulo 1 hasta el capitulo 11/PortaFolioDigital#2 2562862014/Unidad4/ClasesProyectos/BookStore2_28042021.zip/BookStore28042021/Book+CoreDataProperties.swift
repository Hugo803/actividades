//
//  Book+CoreDataProperties.swift
//  BookStore28042021
//
//  Created by alexis on 5/5/21.
//  Copyright © 2021 alexis. All rights reserved.
//

import Foundation
import CoreData


extension Book {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Book> {
        return NSFetchRequest<Book>(entityName: "Book")
    }

    @NSManaged public var price: NSDecimalNumber?
    @NSManaged public var title: String?
    @NSManaged public var yearPublished: Int32
    @NSManaged public var author: Author?

}
