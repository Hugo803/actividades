//
//  Book+CoreDataClass.swift
//  BookStore28042021
//
//  Created by alexis on 5/5/21.
//  Copyright © 2021 alexis. All rights reserved.
//

import Foundation
import CoreData

@objc(Book)
public class Book: NSManagedObject {

}
