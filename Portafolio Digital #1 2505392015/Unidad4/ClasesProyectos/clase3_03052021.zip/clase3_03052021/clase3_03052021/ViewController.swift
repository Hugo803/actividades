//
//  ViewController.swift
//  clase3_03052021
//
//  Created by alexis on 5/5/21.
//  Copyright © 2021 alexis. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let newProduct = NSEntityDescription.insertNewObject(forEntityName: "Productos", into: context)
        newProduct.setValue("Producto 3", forKey: "nombre")
        newProduct.setValue("PRD003", forKey: "codigo")
        newProduct.setValue("tns", forKey: "medida")
        do {
        try context.save()
        print("Gravado")
    }
    catch {
    print("Ocurrio un error")
    }
    //Lista los registros
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Productos")
        request.returnsObjectsAsFaults=false
        do{
            let results = try context.fetch(request)
            if results.count > 0 {
                for result in results as! [NSManagedObject] {
                    if let codiProd = result.value(forKey: "codigo") as?
                        String {
                        let nombProd = result.value(forKey: "nombre") as? String
                        let mediProd = result.value(forKey: "medida") as? String
                        print("Producto:\(codiProd) | \(nombProd!) | \(mediProd!) ")
                    }
                }
            } else {
                print("No registros")
            }
        } catch{
            print("No resultado en fetch")
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

