//
//  ViewController.swift
//  clase7
//
//  
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var mensaje: UITextField!
    
    
    @IBOutlet weak var verMensaje: UILabel!
    
    
    @IBOutlet weak var mostrar: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func asignarmensaje(_ sender: UIButton) {
        verMensaje.text=mensaje.text
    }


}

