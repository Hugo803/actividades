//
//  PrintedMeterial.swift
//  BookStore
//
// 
//

import UIKit

// creando una super clase 
class PrintedMeterial: NSObject {

    var Title:String=""
    var PublishDate:String=""
    var PageCount:String=""
    var Price:String=""
    var Publisher:String=""
    
    func accion() -> String {
        return ""
    }
    
}
