//
//  Author.swift
//  BookStore
//
// 
//

import UIKit

class Author: NSObject {
    var fullName = ""
    var shortName = ""
    var place_of_birth=""
    var year_old=""
    var address = ""
    var city = ""
    var history=""
    
    
    func Perfil() -> String{
        
        fullName = "Aureliano Martinez"
        shortName=" Aurelio"
        place_of_birth="San Salvador"
        year_old = "42 años"
        address=" San miguel, casa #354 "
        city=" San miguel "
        history = "42 años redactando"
        
        return "Nombre del Autor: \(self.fullName), de edad  \(self.year_old)"
    }
    
}
