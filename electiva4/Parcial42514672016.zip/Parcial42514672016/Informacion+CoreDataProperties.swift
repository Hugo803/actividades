//
//  Informacion+CoreDataProperties.swift
//  Parcial42514672016
//
//  Created by alexis on 19/5/21.
//  Copyright © 2021 alexis. All rights reserved.
//
// Wilber Alexis Jorge Ramirez
// 25-1467-2016

import Foundation
import CoreData


extension Informacion {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Informacion> {
        return NSFetchRequest<Informacion>(entityName: "Informacion")
    }

    @NSManaged public var frases: String?

}
