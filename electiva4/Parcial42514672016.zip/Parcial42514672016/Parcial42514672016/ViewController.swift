//
//  ViewController.swift
//  Parcial42514672016
//
//  Created by alexis on 19/5/21.
//  Copyright © 2021 alexis. All rights reserved.

// Wilber Alexis Jorge Ramirez
// 25-1467-2016


import UIKit
import CoreData
class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate  {
    
    
    @IBOutlet weak var myTableView: UITableView!
    
    var managedObjectContext: NSManagedObjectContext!

    override func viewDidLoad() {
        super.viewDidLoad()
        let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
        managedObjectContext = appDelegate.persistentContainer.viewContext as NSManagedObjectContext

        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func dos(_ sender: UIBarButtonItem) {
        let infor: Informacion = NSEntityDescription.insertNewObject(forEntityName: "Informacion", into: managedObjectContext) as! Informacion
        infor.frases = " Libro de texto "
        do{
            try managedObjectContext.save()
        }catch let error as NSError {
            NSLog("My Error: %@", error)
        }
        myTableView.reloadData()
        
    }
    
    
    func loadBooks() -> [Informacion] {
        let fetchRequest: NSFetchRequest<Informacion> = Informacion.fetchRequest()
        var result: [AnyObject] = []
        do {
            result = try managedObjectContext.fetch(fetchRequest)
        } catch let error as NSError {
            NSLog("My Error: %@", error)
        }
        return result as! [Informacion]
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return loadBooks().count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as UITableViewCell?
        let infor: Informacion = loadBooks()[indexPath.row]
        cell?.textLabel?.text = infor.frases
        return cell!
}
}

