//
//  Listprogram+CoreDataProperties.swift
//  Parcial52508302017
//
//  Created by Development on 23/3/21.
//  Copyright © 2021 Development. All rights reserved.
//

//Wilber Alexis Jorge Ramirez
//2514672016

import Foundation

class Book {
    var title:String=""
    var author:String=""

    
}
