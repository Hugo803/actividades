//
//  Listprogram+CoreDataClass.swift
//  Parcial52508302017
//
//  Created by Development on 23/3/21.
//  Copyright © 2021 Development. All rights reserved.
//

//Wilber Alexis Jorge Ramirez
//2514672016


class BookStore {
    var theBookStore: [Book] = []
    
    init() {
        
        var newBook=Book()
        newBook.title=" Pyton "
        newBook.author=" Windows, linux, mac"
        
        
        theBookStore.append(newBook)
        
        newBook=Book()
        newBook.title=" C# "
        newBook.author=" Windows, linux"
        
        theBookStore.append(newBook)
        
        newBook=Book()
        newBook.title=" C++"
        newBook.author=" Windows, linux "
        
        theBookStore.append(newBook)
        
        newBook=Book()
        newBook.title=" Java "
        newBook.author=" Windows, linux "
        
        theBookStore.append(newBook)
    }
    
}
