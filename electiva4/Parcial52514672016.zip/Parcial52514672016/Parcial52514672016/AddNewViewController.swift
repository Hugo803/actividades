//
//  AddNewViewController.swift
//  Parcial52508302017
//
//  Created by Development on 23/3/21.
//  Copyright © 2021 Development. All rights reserved.
//

//Wilber Alexis Jorge Ramirez
//2514672016


import UIKit




protocol BookStoreDelegate {
    func newBook(_ controller: AnyObject, newBook: Book)
    func editBook(_ controller: AnyObject, editBook: Book)
    func deleteBook(_ controller: AnyObject)
}


class AddNewViewController: UIViewController {
    var book = Book()
    var delegate: BookStoreDelegate?
    var read = false
    var editBook = false
    
    @IBOutlet weak var titleText: UITextField!
    @IBOutlet weak var authorText: UITextField!
    @IBOutlet weak var pagesText: UITextField!
    @IBOutlet weak var switchOutlet: UISwitch!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if editBook == true {
            self.title = "Editar"
            titleText.text = book.title
            authorText.text = book.author
            
            
            
        }
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func saveBookAction(_ sender: UIButton) {
        book.title = titleText.text!
        book.author = authorText.text!
        
        
        if (editBook) {
            delegate!.editBook(self, editBook:book)
        }
        else {
            delegate!.newBook(self, newBook:book)
        }
        
        
        
    }
    
}
